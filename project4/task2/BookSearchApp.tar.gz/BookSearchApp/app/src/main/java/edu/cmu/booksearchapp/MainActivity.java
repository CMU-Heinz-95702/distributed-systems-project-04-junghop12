package edu.cmu.booksearchapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import android.content.Context;
import android.view.inputmethod.InputMethodManager;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * Main Activity for the Book Search Android Application.
 * Allows users to search for books using the Open Library API via our web service.
 * 
 * Author: YOUR_NAME YOUR_ANDREW_ID
 */
public class MainActivity extends AppCompatActivity {

    private EditText searchEditText;
    private Button searchButton;
    private TextView resultsTextView;
    private ListView booksListView;
    
    // Deployed web service URL
    private static final String WEB_SERVICE_URL = "https://refactored-journey-x5v7rq649v6qhwx6-8080.app.github.dev/api/books";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // Initialize UI elements
        searchEditText = findViewById(R.id.searchEditText);
        searchButton = findViewById(R.id.searchButton);
        resultsTextView = findViewById(R.id.resultsTextView);
        booksListView = findViewById(R.id.booksListView);
        
        // Set up search button click listener
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String query = searchEditText.getText().toString().trim();
                if (!query.isEmpty()) {
                    // Hide keyboard
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(searchEditText.getWindowToken(), 0);
                    
                    // Execute search in background
                    new BookSearchTask().execute(query);
                } else {
                    Toast.makeText(MainActivity.this, "Please enter a search term", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    
    /**
     * Background task to search for books using the web service API.
     */
    private class BookSearchTask extends android.os.AsyncTask<String, Void, String> {
        
        @Override
        protected void onPreExecute() {
            resultsTextView.setText("Searching...");
            booksListView.setAdapter(null);
        }
        
        @Override
        protected String doInBackground(String... params) {
            String query = params[0];
            HttpURLConnection urlConnection = null;
            StringBuilder result = new StringBuilder();
            
            try {
                // Create URL with query parameter
                String encodedQuery = URLEncoder.encode(query, "UTF-8");
                URL url = new URL(WEB_SERVICE_URL + "?q=" + encodedQuery);
                
                // Open connection
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                
                // Read the response
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }
                
            } catch (IOException e) {
                return "Error: " + e.getMessage();
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
            }
            
            return result.toString();
        }
        
        @Override
        protected void onPostExecute(String result) {
            try {
                // Parse the JSON response
                JSONObject jsonResponse = new JSONObject(result);
                int numFound = jsonResponse.getInt("numFound");
                
                if (numFound > 0) {
                    resultsTextView.setText("Found " + numFound + " books");
                    JSONArray books = jsonResponse.getJSONArray("books");
                    displayBooks(books);
                } else {
                    resultsTextView.setText("No books found");
                    booksListView.setAdapter(null);
                }
                
            } catch (JSONException e) {
                resultsTextView.setText("Error parsing response: " + e.getMessage());
            } catch (Exception e) {
                resultsTextView.setText("Error: " + e.getMessage());
            }
        }
    }
    
    /**
     * Displays the list of books in the ListView.
     */
    private void displayBooks(JSONArray books) throws JSONException {
        List<String> bookItems = new ArrayList<>();
        
        for (int i = 0; i < books.length(); i++) {
            JSONObject book = books.getJSONObject(i);
            String title = book.getString("title");
            String author = book.getString("author");
            String publishYear = book.has("publishYear") ? String.valueOf(book.get("publishYear")) : "Unknown";
            
            String bookInfo = title + "\nby " + author + " (" + publishYear + ")";
            bookItems.add(bookInfo);
        }
        
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_list_item_1, bookItems);
        booksListView.setAdapter(adapter);
    }
}